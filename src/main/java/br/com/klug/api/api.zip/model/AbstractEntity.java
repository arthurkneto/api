package br.com.klug.api.model;

public abstract class AbstractEntity {
}
